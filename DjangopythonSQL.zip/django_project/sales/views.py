from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

import cx_Oracle
cx_Oracle.init_oracle_client(lib_dir="C:/Users/Hosel/Downloads/instantclient-basic/instantclient_19_8")

print(cx_Oracle.clientversion())

ip = '129.7.240.3'
port = 1521
SID = 'orcl'
dsn_tns = cx_Oracle.makedsn(ip, port, SID)


con = cx_Oracle.connect(user="AppannagariT", password="AppannagariT#", dsn=dsn_tns)


cur = con.cursor()
cur.execute("select * from Orders")
customerlist = []
maindict = {}
for customer in cur:
	# print(list(customer))
	customerlist.append(list(customer))

incre = 0
for i in customerlist:
	maindict['sale' + str(incre)] = customerlist[incre]
	incre = incre + 1


def home(request):
	context = {
		'maindict' : customerlist
	}
	return render(request, 'sales/home.html', context)